document.addEventListener("DOMContentLoaded", () => {
    const searchButton = document.getElementById("search-button");
    const pokemonInput = document.getElementById("pokemon-input");
    const pokemonInfoDiv = document.getElementById("pokemon-info");
    const historyList = document.getElementById("history-list");
    const pokemonList = document.getElementById("pokemon-list");
    const pokemonLoading = document.getElementById("pokemon-loading");
    const loadMoreButton = document.getElementById("load-more-button");

    let history = [];
    let offset = 0;
    const limit = 20;

    // Mapa de cores por tipo
    const pokemonTypes = {
        normal: "#A8A77A",
        fire: "#EE8130",
        water: "#6390F0",
        electric: "#F7D02C",
        grass: "#7AC74C",
        ice: "#96D9D6",
        fighting: "#C22E28",
        poison: "#A33EA1",
        ground: "#E2BF65",
        flying: "#A98FF3",
        psychic: "#F95587",
        bug: "#A6B91A",
        rock: "#B6A136",
        ghost: "#735797",
        dragon: "#6F35FC",
        dark: "#705746",
        steel: "#B7B7CE",
        fairy: "#D685AD"
    };

    // Buscar Pokémon
    searchButton.addEventListener("click", () => {
        const query = pokemonInput.value.toLowerCase().trim();
        if (query) fetchPokemon(query);
    });

    pokemonInput.addEventListener("keydown", e => {
        if (e.key === "Enter") searchButton.click();
    });

    async function fetchPokemon(name) {
        pokemonInfoDiv.innerHTML = "<p>Carregando...</p>";

        try {
            const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${name}`);
            if (!res.ok) throw new Error("Pokémon não encontrado");

            const data = await res.json();
            displayPokemon(data);
            addToHistory(data);
        } catch (err) {
            pokemonInfoDiv.innerHTML = `<p style="color:red;">${err.message}</p>`;
        }
    }

    function displayPokemon(p) {
        const img = p.sprites.other["official-artwork"].front_default;
        const primaryType = p.types[0].type.name;

        const bgColor = pokemonTypes[primaryType] || "#fff";
        pokemonInfoDiv.style.backgroundColor = bgColor;

        // Remove classes
        pokemonInfoDiv.classList.remove("type-light", "type-dark");

        // Define contraste automático
        if (["electric","grass","fairy","ice","normal"].includes(primaryType)) {
            pokemonInfoDiv.classList.add("type-light");
        } else {
            pokemonInfoDiv.classList.add("type-dark");
        }

        pokemonInfoDiv.innerHTML = `
            <h2>${p.name} (#${p.id})</h2>
            <img src="${img}" width="200">
            <p><b>Tipo:</b> ${primaryType}</p>
            <p><b>Altura:</b> ${p.height / 10}m</p>
            <p><b>Peso:</b> ${p.weight / 10}kg</p>
        `;
    }

    function addToHistory(p) {
        history = history.filter(x => x.id !== p.id);
        history.unshift(p);
        updateHistoryUI();
    }

    function updateHistoryUI() {
        historyList.innerHTML = "";
        history.forEach(p => {
            const li = document.createElement("li");
            li.innerHTML = `<a href="#">${p.name} (#${p.id})</a>`;
            li.onclick = () => fetchPokemon(p.id);
            historyList.appendChild(li);
        });
    }

    // Carregar lista de pokémons
    async function loadPokemons() {
        pokemonLoading.style.display = "block";

        const res = await fetch(`https://pokeapi.co/api/v2/pokemon?offset=${offset}&limit=${limit}`);
        const data = await res.json();

        for (const poke of data.results) {
            const detail = await fetch(poke.url).then(r => r.json());
            addPokemonCard(detail);
        }

        pokemonLoading.style.display = "none";
        offset += limit;
    }

    function addPokemonCard(p) {
        const img = p.sprites.front_default;
        const card = document.createElement("div");

        card.className = "pokemon-small-card";
        card.innerHTML = `
            <img src="${img}">
            <p>${p.name}</p>
        `;

        card.onclick = () => displayPokemon(p);

        pokemonList.appendChild(card);
    }

    loadMoreButton.addEventListener("click", loadPokemons);

    loadPokemons();
});